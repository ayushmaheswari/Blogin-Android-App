package com.example.bloggeradda.loginSignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bloggeradda.HomeActivity;
import com.example.bloggeradda.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class login1 extends AppCompatActivity {

    private FirebaseAuth mAuth;
    EditText number,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login1);
        mAuth = FirebaseAuth.getInstance();
        number = (EditText)findViewById(R.id.number);
        password = (EditText)findViewById(R.id.password);
    }
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser!=null) {
            Intent i = new Intent(this, HomeActivity.class);
            startActivity(i);
            finish();
        }
    }

    public void LoginInto(View view) {
        String mNumber = number.getText().toString();
        String mPassword = password.getText().toString();
        if(mNumber.isEmpty())
        {
            number.setError("please fill the Number");
            number.requestFocus();
        }
        else if(mPassword.isEmpty())
        {
            password.setError("please fill the password");
            password.requestFocus();
        }
        else if(!mNumber.isEmpty() && !mPassword.isEmpty())
        {
            mAuth.signInWithEmailAndPassword(mNumber, mPassword)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                FirebaseUser user = mAuth.getCurrentUser();
                                startActivity(new Intent(getApplicationContext(),HomeActivity.class));
                                finish();

                            } else {
                                Toast.makeText(getApplicationContext(), "Authentication failed.", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
        }
        else
        {

        }

    }

    public void signup(View view) {
        Intent i = new Intent(getApplicationContext(),signup.class);
        startActivity(i);
        finish();
    }


}
