package com.example.bloggeradda;

public class BlogModel {
    String userId="";
    String blogtitle="";
    String blogContent="";
    String category="";
    String imageUrl="";

    public BlogModel(String userId, String blogtitle, String blogContent, String category, String imageUrl) {
        this.userId = userId;
        this.blogtitle = blogtitle;
        this.blogContent = blogContent;
        this.category = category;
        this.imageUrl = imageUrl;
    }
    public BlogModel()
    {

    }
    public BlogModel(String blogtitle, String blogContent, String category) {
        this.blogtitle = blogtitle;
        this.blogContent = blogContent;
        this.category = category;
    }

    public String getUserId() {
        return userId;
    }

    public String getBlogtitle() {
        return blogtitle;
    }

    public String getBlogContent() {
        return blogContent;
    }

    public String getCategory() {
        return category;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
