package com.example.bloggeradda;

import androidx.annotation.NonNull;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.bloggeradda.loginSignup.login1;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Locale;

public class HomeActivity extends AppCompatActivity {

    ListView lv;
    MyAdopter mad;
    ArrayList<BlogModel> al;

   DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        lv = findViewById(R.id.listview);
        al = new ArrayList<BlogModel>();
        databaseReference = FirebaseDatabase.getInstance().getReference("Blog");

        ValueEventListener postListner = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren())
                {
                    BlogModel blog = snapshot.getValue(BlogModel.class);
                    al.add(blog);
                }
                mad  = new MyAdopter(getApplicationContext(),al);
                lv.setAdapter(mad);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        databaseReference.addValueEventListener(postListner);




    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.newblog)
        {
            Intent i = new Intent(getApplicationContext(),newBlog.class);
            startActivity(i);
        }
        else if(item.getItemId()==R.id.logout)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setIcon(R.drawable.logout);
            builder.setTitle("Sign Out");
            builder.setMessage("Are you sure want to Sign Out");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                    FirebaseAuth.getInstance().signOut();
                    startActivity(new Intent(getApplicationContext(), login1.class));
                    finish();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
        else if(item.getItemId()==R.id.all)
        {

        }
        else if(item.getItemId()==R.id.politics)
        {

        }
        else if(item.getItemId()==R.id.sports)
        {

        }
        else if(item.getItemId()==R.id.technology)
        {

        }
        else if(item.getItemId()==R.id.news)
        {

        }
        else if(item.getItemId()==R.id.traveling)
        {

        }
        else if(item.getItemId()==R.id.arts)
        {

        }
        else if(item.getItemId()==R.id.education)
        {

        }
        else if(item.getItemId()==R.id.other)
        {

        }
        else
        {

        }
        return true;
    }


}
