package com.example.bloggeradda.loginSignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bloggeradda.HomeActivity;
import com.example.bloggeradda.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;

public class signup extends AppCompatActivity {

    EditText number,password,confirmPassword;

    private FirebaseAuth mFirebaseAuth;
    private DatabaseReference mRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        mFirebaseAuth = FirebaseAuth.getInstance();

        number = (EditText)findViewById(R.id.number);
        password = (EditText)findViewById(R.id.password);
        confirmPassword = (EditText)findViewById(R.id.confirmpassword);

    }

    public void login(View view) {
        Intent i = new Intent(getApplicationContext(),login1.class);
        startActivity(i);
        finish();
    }

    public void SignupInto(View view) {
        String mNumber = number.getText().toString();
        String mPassword = password.getText().toString();
        String mConfirmPassword= confirmPassword.getText().toString();

        if(mNumber.isEmpty())
        {
            number.setError("please fill the Number");
            number.requestFocus();
        }
        else if(mPassword.isEmpty())
        {
            password.setError("please fill the password");
            password.requestFocus();
        }
        else if(mConfirmPassword.isEmpty())
        {
            confirmPassword.setError("please fill the confirm password");
            confirmPassword.requestFocus();
        }
        else if(!mNumber.isEmpty() && !mPassword.isEmpty() && !mConfirmPassword.isEmpty()) {
            if (mPassword.equals(mConfirmPassword)) {
                mFirebaseAuth.createUserWithEmailAndPassword(mNumber, mPassword)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    FirebaseUser user = mFirebaseAuth.getCurrentUser();
                                    startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                                    finish();

                                } else {
                                    Toast.makeText(getApplicationContext(), "Authentication failed.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
            else
            {
                Toast.makeText(this, "Password not match...", Toast.LENGTH_SHORT).show();
                confirmPassword.requestFocus();
            }
        }
        else
        {
            Toast.makeText(signup.this, "Error Occur , try again...", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mFirebaseAuth.getCurrentUser();
        if(currentUser!=null)
        {
            Intent i = new Intent(getApplicationContext(),HomeActivity.class);
            startActivity(i);
            finish();
        }
    }
}

