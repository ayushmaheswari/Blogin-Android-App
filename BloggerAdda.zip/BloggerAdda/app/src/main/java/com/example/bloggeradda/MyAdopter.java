package com.example.bloggeradda;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

class MyAdopter extends BaseAdapter {



    Context ct;
    ArrayList<BlogModel> al;


    public MyAdopter(Context ct , ArrayList<BlogModel> al)
    {
        this.ct = ct;
        this.al =al;
    }

    @Override
    public int getCount() {
        return al.size();
    }

    @Override
    public Object getItem(int position) {
        return al.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        BlogModel p = (BlogModel) getItem(position);
        Activity at  =(Activity) ct;

        View v1 = at.getLayoutInflater().inflate(R.layout.list,null,false);
        TextView tv1 = v1.findViewById(R.id.title);
        TextView tv2 = v1.findViewById(R.id.category);
        TextView tv3 = v1.findViewById(R.id.content);

        tv1.setText(p.getBlogtitle());
        tv2.setText(p.getCategory());
        tv3.setText(p.getBlogContent());

        Log.i("values123 ",""+p.getBlogtitle());
        Log.i("values123 ",""+p.getCategory());
        Log.i("values123 ",""+p.getBlogContent());
        return v1;
    }
}
