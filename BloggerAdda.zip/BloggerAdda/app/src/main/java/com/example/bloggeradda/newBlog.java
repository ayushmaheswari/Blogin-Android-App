package com.example.bloggeradda;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.UUID;

public class newBlog extends AppCompatActivity {

    StorageReference UploadTask;

    DatabaseReference databaseReference;
    StorageReference storageReference;
    private StorageReference storageRef;
    FirebaseStorage storage = FirebaseStorage.getInstance();

    String url="";

    String[] category = {"Politics", "Sports", "Technology", "News", "Traveling", "Arts", "Education", "Other"};
    private ImageView imageView;
    private Spinner spinner;
    private static final int GALLERY_REQUEST_CODE = 2;
    Bitmap bitmap;

    private Uri uri ;
    private EditText textTitle;
    private EditText textDesc;
    private Button postBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_blog);

        imageView = (ImageView) findViewById(R.id.displayImage);
        spinner = (Spinner) findViewById(R.id.spinner);
        postBtn = findViewById(R.id.postBtn);

        databaseReference = FirebaseDatabase.getInstance().getReference("Blog");
        storageReference = FirebaseStorage.getInstance().getReference("blog");

        textDesc = findViewById(R.id.textDesc);
        textTitle = findViewById(R.id.textTitle);

        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, category);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(aa);


        postBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadimage();
                finish();
            }
        });


    }

    public void pickFromGallery(View view) {
        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK) {
            uri = data.getData();
            try {
                InputStream imageStream = null;
                imageStream = getContentResolver().openInputStream(uri);
                bitmap = BitmapFactory.decodeStream(imageStream);
                imageView.setImageURI(uri);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }
    }


    private String getFileExtension(Uri uri) {
        ContentResolver cr = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(uri));
    }

    public void uploadimage() {

        if (uri != null) {
            final String abc="username"+System.currentTimeMillis() + "." + getFileExtension(uri);
            final StorageReference filerefence = storageReference.child(abc);
            filerefence.putFile(uri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            String uid = user.getUid().toString();
                            String title = textTitle.getText().toString();
                            String desc = textDesc.getText().toString();

                            String cate = spinner.getSelectedItem().toString();
                            BlogModel blogModel = new BlogModel(uid, title, desc, cate, abc);
                            String blogId = databaseReference.push().getKey();
                            databaseReference.child(blogId).setValue(blogModel);
                            Toast.makeText(newBlog.this, "Blog Posted...", Toast.LENGTH_SHORT).show();
                            imageView.setImageURI(uri);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {

            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            String uid = user.getUid().toString();
            String title = textTitle.getText().toString();
            String desc = textDesc.getText().toString();

            String cate = spinner.getSelectedItem().toString();
            BlogModel blogModel = new BlogModel(uid, title, desc, cate,"no image selected");
            String blogId = databaseReference.push().getKey();
            databaseReference.child(blogId).setValue(blogModel);
            Toast.makeText(newBlog.this, "Blog Posted...", Toast.LENGTH_SHORT).show();

             Toast.makeText(getApplicationContext(), "no image selected", Toast.LENGTH_SHORT).show();
        }
    }

}
